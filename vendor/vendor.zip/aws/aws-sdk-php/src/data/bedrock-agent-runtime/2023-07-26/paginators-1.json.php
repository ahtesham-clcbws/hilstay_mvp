<?php
// This file was auto-generated from sdk-root/src/data/bedrock-agent-runtime/2023-07-26/paginators-1.json
return [ 'pagination' => [ 'Retrieve' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'result_key' => 'retrievalResults', ], ],];
